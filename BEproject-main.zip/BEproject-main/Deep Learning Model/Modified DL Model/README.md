# Modifications: 
#### Loss Function is changed to --> binary_crossentropy
#### Training Accuracy: 0.9258 
#### New saved model: heartbeat_classifier_binary_crossentropy.h5
#### Class values 0 and 1 are interchanged 
