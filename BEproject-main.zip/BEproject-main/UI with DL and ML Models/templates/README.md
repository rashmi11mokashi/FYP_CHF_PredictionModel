All templates
