1. Download the folder
2. Run import_MLmodel.py first and only ONCE(model.h5 will be created)
3. Run main.py(prediction value and classification will be displayed)
