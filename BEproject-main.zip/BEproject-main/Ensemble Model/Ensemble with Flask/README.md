Ensemble with Flask
