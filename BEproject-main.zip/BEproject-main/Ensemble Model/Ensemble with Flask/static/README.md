Contains CSS and other files
